# basic-sample-php-template-example
Explanation for organizing the file structure
