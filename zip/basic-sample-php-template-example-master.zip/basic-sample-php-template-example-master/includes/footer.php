<div class="footer">
	&copy; <?php print date("Y");?>
</div>