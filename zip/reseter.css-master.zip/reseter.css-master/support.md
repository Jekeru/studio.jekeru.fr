# Support

> This project has a [code of conduct](https://github.com/krishdevdb/reseter.css/blob/master/.github/contributing.md).
> By interacting with this repository, or community you agree to
> abide by its terms.

Hi! 👋
We’re excited that you’re using **reseter.css** and we’d love to help.

*   [Chat Us On Discord](https://discord.gg/xqh38kb6sv)
*   [Start A Discussion On Github](https://github.com/krishdevdb/reseter.css/discussions)
*   [Add A Issue On Github](https://github.com/krishdevdb/reseter.css/issues)
