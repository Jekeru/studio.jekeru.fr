# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

## Reporting a Vulnerability

Use this section to tell people how to report a vulnerability.

To Report A Vulnerability. Kindly Create A Issue On Github
