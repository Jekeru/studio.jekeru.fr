var stepsX = 30,
    stepsY = 60;

$(document).mousemove(function (event) {

  var percentWidth = event.pageX / $(document).width();
  var percentHeight = event.pageY / $(document).height();

  var moveX = ((percentHeight - 0.5) * stepsX) - 26;
  var moveY = ((percentWidth - 0.5) * stepsY) + 36;

  $('.scene').css("transform", "rotateX(" + moveX + "deg) rotateY(" + moveY + "deg)");
});